//
//  TalkTechApp.swift
//  TalkTech
//
//  Created by Lilly Toma on 10/12/24.
//

import SwiftUI

@main
struct TalkTechApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
