import SwiftUI
import UIKit

struct DocumentPicker: UIViewControllerRepresentable {
    var completion: (URL?) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.pdf])
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(_ parent: DocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            parent.completion(urls.first)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.completion(nil)
        }
    }
}



struct ContentView: View {
    var body: some View {
        ZStack {
            // Tab View with the other content
            TabView {
                EventsView()
                    .tabItem {
                        Image(systemName: "star")
                        Text("Events")
                    }
                
                ScheduledView()
                    .tabItem {
                        Image(systemName: "calendar")
                        Text("Scheduled")
                    }
                
                ProfileView()
                    .tabItem {
                        Image(systemName: "person.circle")
                        Text("Profile")
                    }
            }
        }
    }
}

struct EventsView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("Talk Tech")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 50)

                SearchBar()
                
                ScrollView {
                    VStack(alignment: .leading) {
                        Text("Explore")
                            .font(.title)
                            .fontWeight(.bold)
                            .padding(.leading)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 20) {
                                NavigationLink(destination: EventDetailView(eventTitle: "AI For Today", eventLocation: "345 Evan Rd, Ann Arbor MI", eventTime: "Monday, June 12th, 2024 @5pm", eventImageName: "explore1")) {
                                    ExploreItem(imageName: "explore1", text: "AI For Today")
                                }
                                
                                NavigationLink(destination: EventDetailView(eventTitle: "Today Is The New Tomorrow", eventLocation: "8765 John Dr, Detroit MI", eventTime: "Monday, June 12th, 2024 @5pm", eventImageName: "explore2")) {
                                    ExploreItem(imageName: "explore2", text: "Today Is The New Tomorrow")
                                }
                                
                                NavigationLink(destination: EventDetailView(eventTitle: "Hello GPT", eventLocation: "432 Yasmne Dr, Detroit MI", eventTime: "Monday, June 12th, 2024 @5pm", eventImageName: "explore3")) {
                                    ExploreItem(imageName: "explore3", text: "Hello GPT")
                                }
                            }
                            .padding(.leading)
                            .padding(.trailing)
                        }
                        
                        Text("Nearby")
                            .font(.title)
                            .fontWeight(.bold)
                            .padding(.leading)
                            .padding(.top)
                        
                        // First Nearby Section
                        NearbyView()
                        
                        // Second Nearby Section
                        NearbyView()
                    }
                }
                
                Spacer()
            }
        }
    }
}

struct EventDetailView: View {
    var eventTitle: String
    var eventLocation: String
    var eventTime: String
    var eventImageName: String
    var registeredUsers: [RegisteredUser] = [
        RegisteredUser(
            name: "John Doe",
            profileImage: "person.circle",
            school: "Wayne State University",
            level: "Undergraduate",
            experience: [
                Experience(title: "Systems Testing Engineer", company: "Ally", period: "2023-Curr"),
                Experience(title: "Accountant", company: "Chase Bank", period: "2021-2023")
            ],
            education: [
                Education(institution: "Wayne State University", period: "2021-2023")
            ],
            resume: "JohnDoeResume.pdf"
        ),
        RegisteredUser(
            name: "Jane Smith",
            profileImage: "person.circle.fill",
            school: "University of Michigan",
            level: "Graduate",
            experience: [
                Experience(title: "Software Engineer", company: "Google", period: "2022-Curr"),
                Experience(title: "Intern", company: "Microsoft", period: "2020-2022")
            ],
            education: [
                Education(institution: "University of Michigan", period: "2020-2022")
            ],
            resume: "JaneSmithResume.pdf"
        ),
        // Add more registered users as needed
        RegisteredUser(
            name: "Nuri Toma",
            profileImage: "person.circle.fill",
            school: "Wayne State University",
            level: "Graduate",
            experience: [
                Experience(title: "Software Engineer", company: "Google", period: "2022-Curr"),
                Experience(title: "Intern", company: "Microsoft", period: "2020-2022")
            ],
            education: [
                Education(institution: "University of Michigan", period: "2020-2022")
            ],
            resume: "JaneSmithResume.pdf"
        ),
    ]

    var body: some View {
        VStack {
            Image(eventImageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 300)
                .clipped()
            
            Text(eventTitle)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top)

            Text(eventLocation)
                .font(.headline)
                .padding(.top, 5)

            Text(eventTime)
                .font(.subheadline)
                .padding(.top, 5)
            
            Text("Registered Users")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.top, 20)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20) {
                    ForEach(registeredUsers) { user in
                        NavigationLink(destination: UserProfileView(user: user)) {
                            VStack {
                                Image(systemName: user.profileImage)
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .clipShape(Circle())
                                    .padding()

                                Text(user.name)
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .padding(.top, 5)

                                Text(user.school)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)

                                Text(user.level)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                
                                // Additional user details can be added here
                            }
                            .background(Color(.systemGray6))
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .padding(.vertical, 5)
                            .padding(.horizontal, 10)
                        }
                    }
                }
                .padding()
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle(eventTitle)
    }
}


struct RegisteredUser: Identifiable {
    let id = UUID()
    let name: String
    let profileImage: String
    let school: String
    let level: String
    let experience: [Experience]
    let education: [Education]
    let resume: String
}

struct Experience: Identifiable {
    let id = UUID()
    let title: String
    let company: String
    let period: String
}

struct Education: Identifiable {
    let id = UUID()
    let institution: String
    let period: String
}

struct UserProfileView: View {
    var user: RegisteredUser

    var body: some View {
        NavigationView {
            VStack {
                // Profile Picture
                Circle()
                    .fill(Color(.darkGray)) // Dark background for the circle
                    .frame(width: 100, height: 100)
                    .padding(.top, 50)

                // User Name
                Text(user.name)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 10)

                // School and Level
                Text("School: \(user.school)")
                    .font(.subheadline)
                Text("Level: \(user.level)")
                    .font(.subheadline)

                // Experience Section
                VStack(alignment: .leading) {
                    Text("Experience")
                        .font(.title3)
                        .padding(.top, 20)

                    ForEach(user.experience) { exp in
                        HStack {
                            Text("\(exp.title) at \(exp.company)")
                            Spacer()
                            Text(exp.period)
                        }
                        .padding(.vertical, 5)
                    }
                }
                .padding(.horizontal)

                // Education Section
                VStack(alignment: .leading) {
                    Text("Education")
                        .font(.title3)
                        .padding(.top, 20)

                    ForEach(user.education) { edu in
                        HStack {
                            Text(edu.institution)
                            Spacer()
                            Text(edu.period)
                        }
                        .padding(.vertical, 5)
                    }


                // Attachments Section
                    Text("Resume")
                        .font(.headline)
                        .padding(.top, 20)

                    if let resumeURL = URL(string: user.resume) {
                        Link(user.resume, destination: resumeURL)
                            .foregroundColor(.blue)
                            .padding(.top, 5)
                    } else {
                        Text("No Resume Attached")
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding(.bottom, 50) // Padding to avoid overlap with tab bar
            .background(Color.black.edgesIgnoringSafeArea(.all)) // Background color
            .navigationTitle(user.name)
        }
    }
}


struct SearchBar: View {
    @State private var searchText = ""

    var body: some View {
        HStack {
            TextField("Search", text: $searchText)
                .padding(7)
                .padding(.horizontal, 25)
                .background(Color(.darkGray))
                .cornerRadius(8)
                .overlay(
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                            .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 8)

                        if !searchText.isEmpty {
                            Button(action: {
                                self.searchText = ""
                            }) {
                                Image(systemName: "multiply.circle.fill")
                                    .foregroundColor(.gray)
                                    .padding(.trailing, 8)
                            }
                        }
                    }
                )
                .padding(.horizontal, 10)
        }
        .padding(.top, 10)
    }
}

//struct ExploreItem: View {
//    var imageName: String
//    var text: String
//
//    var body: some View {
//        VStack {
//            Image(imageName)
//                .resizable()
//                .aspectRatio(contentMode: .fit)
//                .frame(height: 150)
//            
//            Text(text)
//                .padding(.horizontal)
//                .padding(.top, 5)
//        }
//    }
//}
struct ExploreItem: View {
    var imageName: String
    var text: String

    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 150)
                .background(.black)

            Text(text)
                .padding(.horizontal)
                .padding(.top, 5)
        }
        //.padding(.vertical) // Add some padding to space items, if needed
        .background(.black)
    }
}

struct NearbyView: View {
    @State private var isRegistered = false

    var body: some View {
        HStack {
            Image("nearby")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 200)
                .padding()
            VStack(alignment: .leading) {
                Text("Location: 4747 Anthony Wayne Dr")
                Text("Time: 9am - 5pm")
                Text("Seats Left: 20")
                
                Button(action: {
                    self.isRegistered.toggle()
                }) {
                    Text("Register")
                        .fontWeight(.bold)
                        .frame(minWidth: 0, maxWidth: .infinity)
                        .padding()
                        .foregroundColor(.white)
                        .background(isRegistered ? Color.green : Color.gray)
                        .cornerRadius(10)
                }
                .padding(.top, 10)
            }
            .padding(.leading)
        }
        .padding(.leading)
        .padding(.trailing)
    }
}

import SwiftUI

import SwiftUI

struct ScheduledView: View {
    @State private var selectedDate = Date()

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Button(action: {
                        selectedDate = Calendar.current.date(byAdding: .day, value: -1, to: selectedDate) ?? selectedDate
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.title)
                    }

                    Spacer()
                    
                    Text(formatDate(selectedDate))
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()
                    
                    Button(action: {
                        selectedDate = Calendar.current.date(byAdding: .day, value: 1, to: selectedDate) ?? selectedDate
                    }) {
                        Image(systemName: "chevron.right")
                            .font(.title)
                    }
                }
                .padding()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        ScheduledEventItem(
                            title: "Tech Town KeyNote",
                            location: "4747 Anthony Wayne Dr, Detroit MI",
                            time: "8:00am - 5:00pm",
                            imageName: "explore1"
                        )
                        
                        ScheduledEventItem(
                            title: "Google Speaker on AI",
                            location: "647 Nelson Dr, Ann Arbor MI",
                            time: "9:00am - 12:00pm",
                            imageName: "explore2"
                        )
                    }
                    .padding()
                }
                
                Spacer()
            }
        }
    }
    
    // Function to format the date without the year
    private func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE, MMMM d" // e.g., "Saturday, October 13"
        return dateFormatter.string(from: date)
    }
}



struct ScheduledEventItem: View {
    var title: String
    var location: String
    var time: String
    var imageName: String
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(title)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(location)
                
                Text(time)
            }
            
            Spacer()
            
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .clipped()
        }
    }
}


struct ProfileView: View {
    
    @State private var showingDocumentPicker = false
    @State private var resumeURL: URL? = nil // To hold the selected resume URL
    @State private var resumeName: String = "No Resume Attached" // To display the attached resume name

    var body: some View {
        NavigationView {
            VStack {
                // Profile Picture
                Circle()
                    .fill(Color(.darkGray)) // Dark background for the circle
                    .frame(width: 100, height: 100)
                    .overlay(
                        Text("JD") // Placeholder for initials
                            .font(.largeTitle)
                            .foregroundColor(.black)
                    )
                    .padding(.top, 50)

                // User Name
                Text("John Doe")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 10)

                // Affiliation and Level
                Text("Affiliation: Wayne State University")
                    .font(.subheadline)
                Text("Level: Undergraduate")
                    .font(.subheadline)

                // Experience Section
                VStack(alignment: .leading) {
                    Text("Experience")
                        .font(.title3)
                        .padding(.top, 20)

                    HStack {
                        Text("Ally: Systems Testing Engineer")
                        Spacer()
                        Text("2023-Curr")
                    }
                    .padding(.vertical, 5)
                    
                    HStack {
                        Text("Chase Bank: Accountant")
                        Spacer()
                        Text("2021-2023")
                    }
                    .padding(.vertical, 5)

                    // Education Section
                    Text("Education")
                        .font(.title3)
                        .padding(.top, 20)
                    HStack {
                        Text("Wayne State University")
                        Spacer()
                        Text("2021-2023")
                    }
                }
                .padding(.horizontal)

                // Attachments Section
                VStack(alignment: .leading) {
                    Text("Attachments")
                        .font(.headline)
                        .padding(.top, 20)

                    Text(resumeName) // Display the attached resume name

                    Button(action: {
                        showingDocumentPicker = true // Show the document picker
                    }) {
                        Text("Attach Resume")
                            .fontWeight(.bold)
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .padding()
                            .background(Color(.darkGray))
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.top, 5)
                        .sheet(isPresented: $showingDocumentPicker) {
                            DocumentPicker { url in
                                if let url = url {
                                    resumeURL = url
                                    resumeName = url.lastPathComponent // Display the resume name
                                }
                            }
                        
                        }
                    }
                }

                Spacer()
            }
            .padding(.bottom, 50) // Padding to avoid overlap with tab bar
            .background(Color.black.edgesIgnoringSafeArea(.all)) // Background color
        }
    }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
