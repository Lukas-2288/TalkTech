import CoreData
import SwiftUI
import Combine

class EventManager: ObservableObject {
    @Published var scheduledEvents: [ScheduledEvent] = []
    
    func addEvent(_ event: ScheduledEvent) {
        scheduledEvents.append(event)
    }
}

struct ScheduledEvent: Identifiable {
    let id = UUID()
    let title: String
    let location: String
    let time: String
}


struct PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentContainer

    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "DataModel") // Ensure this matches your .xcdatamodeld name
        if inMemory {
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
    }
    
    func saveEvent(title: String, location: String, date: Date) {
        let context = container.viewContext
        let newEvent = Event(context: context) // Make sure Event is imported or accessible
        newEvent.title = title
        newEvent.location = location
        newEvent.date = date

        do {
            try context.save()
        } catch {
            print("Failed to save event: \(error)")
        }
    }
}
